package com.example.ex20230512


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley

class MainActivity : AppCompatActivity() {

    lateinit var btnReq:Button
    lateinit var etUrl:EditText
    lateinit var tvResult: TextView

    //요청이 담길 Queue객체는 만들어져 있어야 합니다.
    lateinit var queue:RequestQueue


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnReq=findViewById(R.id.btnReq)
        etUrl=findViewById(R.id.etURL)
        tvResult=findViewById(R.id.tvResult)

        queue= Volley.newRequestQueue(applicationContext)
        //1.btnReq를 눌렀을 때, etUrl에 적혀있는 Url 주소값을 가지고온다.


        //2.Request,RequestQueue 두개의 객체가 필요합니다.
        btnReq.setOnClickListener {
            val url=etUrl.text.toString()
            // StringRequest
            val request=StringRequest(
                //1. 요청 방식 (GET/POST)
            Request.Method.GET,
                url,
                {
                //응답을 성공했을때 받아온 결과값이 String
                //응답을 받아왔을때 실행시킬 코드
                tvResult.text=it.toString()
                },
                {
                //응답을 실패했을때 실행시킬 코드
                    Toast.makeText(this@MainActivity,"실패",Toast.LENGTH_SHORT).show()
                }
            )

            //캐시메모리 누적된것을 정리해줘야합니다. 렉방지용
            request.setShouldCache(false)

            // request를 만든 후에 queue에 더해주자
            queue.add(request)


        }




    }
}