package com.example.ex20230512

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView


class MovieAdapter(context: Context, layout: Int ,movieList: MutableList<MovieVO>)
    :RecyclerView.Adapter<MovieAdapter.ViewHolder>(){
    val context = context
    val layout=layout
    val movieList =movieList
    //inflater는 Activity의 힘을빌려
    val inflater=LayoutInflater.from(context)

    class ViewHolder(view:View): RecyclerView.ViewHolder(view){
    val tvMoviewNm:TextView=view.findViewById(R.id.tvMovieNm)
        val tvOldAndNew:TextView=view.findViewById(R.id.tvOldAndNew)
        val tvAcc:TextView=view.findViewById(R.id.tvAcc)
        val tvDt:TextView=view.findViewById(R.id.tvDt)
        val tvRank:TextView=view.findViewById(R.id.tvRank)

    }
    //1. 한칸에 들어갈 디자인을 inlfater해서 ViewHolder로 보내자
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view=inflater.inflate(layout,parent,false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return movieList.size

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tvMoviewNm.text=movieList[position].MovieNm
        holder.tvAcc.text=movieList[position].audiAcc
        holder.tvOldAndNew.text=movieList[position].rankOldAndNew
        holder.tvDt.text=movieList[position].openDt
        holder.tvRank.text=movieList[position].rank
    }
}