package com.example.ex20230512

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class MovieActivity : AppCompatActivity() {
    //Queue만들자
    lateinit var queue:RequestQueue



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie)

        val btnSend:Button=findViewById(R.id.btnSend)
        val movieList = mutableListOf<MovieVO>()
        val rcv:RecyclerView=findViewById(R.id.rcv)
        queue= Volley.newRequestQueue(applicationContext)

        //url값을 미리 준비해두자 request만들기 전에
        val url="http://kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.json?key=f5eef3421c602c6cb7ea224104795888&targetDt=20220909"

        //1. btnSend를 클릭했을떄 영화정보를 받아오자!
        btnSend.setOnClickListener {
            //request,requestQueue
            val request = StringRequest(
                //1. 전송방식 (GET/POST)
            Request.Method.GET,
                url,
                //3. 응답성공시
                {
                    val json1=JSONObject(it)
                    Log.d("json",json1.toString())
                    val json2=json1.getJSONObject("boxOfficeResult")
                    Log.d("json",json2.toString())
                    val movies=json2.getJSONArray("dailyBoxOfficeList")
                    Log.d("movies",movies.toString())

                    for(i in 0  until movies.length()){
                        val movie =movies.get(i) as JSONObject//movie는 JSONObject
                        //1. rank
                        val rank=movie.getString("rank")
                        //2.rankOldandNew
                        val rankOldAndNew= movie.getString("rankOldAndNew")
                        //3.movieNM
                        val movieNM=movie.getString("movieNm")
                        //4. openDt
                        val openDt=movie.getString("openDt")
                        //5. audiAcc
                        val audiAcc =movie.getString("audiAcc")
                        Log.d("movie1","$rank,$rankOldAndNew")

                        //MovieVO를 만들자!
                        movieList.add(MovieVO(rank,rankOldAndNew,movieNM,openDt,audiAcc))
                    }
                },
                {
                    Toast.makeText(this@MovieActivity,"실패",Toast.LENGTH_SHORT).show()
                }
            )
            //큐에다가 리퀘스트를 실어서 보내줍니다~ 캐시정리도 겸으로
            request.setShouldCache(false)
            queue.add(request)

            //데이터를 받아오고난후 디자인이랑 합치는 작업을 진행
          val adapter  = MovieAdapter(applicationContext,R.layout.listitem,movieList)
            //화면정보,한칸디자인,서버에서 받아온 데이터
            rcv.layoutManager=LinearLayoutManager(applicationContext,
            LinearLayoutManager.VERTICAL,false)
            rcv.adapter=adapter

        }


    }
}