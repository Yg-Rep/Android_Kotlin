package com.example.ex20230512

data class MovieVO(
    val rank: String="",
    val rankOldAndNew:String="",
    val MovieNm: String="",
    val openDt: String="",
    val audiAcc:String=""

)
