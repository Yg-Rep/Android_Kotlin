package com.example.pokemonexample

data class PokemonVO (
    var imgId:Int=0,
    var name:String="",
    var skill:String="",
    var feature:String=""
        )