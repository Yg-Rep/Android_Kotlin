package com.example.pokemonexample

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast


class PokemonAdapter(context:Context,layout:Int,pokemonList: MutableList<PokemonVO>):BaseAdapter()
{
private val context=context
private val layout=layout
private val pokemonList=pokemonList
private val inflater=LayoutInflater.from(context)

 override fun getCount(): Int {
   //항목의 개수
  return pokemonList.size
 }

 override fun getItem(position: Int): Any {
  //포켓몬리스트의 포지션번째있는 항목을 돌려줄겁니다.
  return pokemonList[position]
 }

 override fun getItemId(position: Int): Long {
 return position.toLong()
 }

 override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
 //****데이터랑 뷰를 합쳐서 리스트뷰에 한칸 한칸 적재시키는 역할을 하는 친구

  // 이전에 만들어진 뷰가 없으면 inflate 작업이 한번도 일어나지 않은 상황
  var view=convertView

  //null인지 판단하는 이유는 inflate 작업을 한번만 하기 위해서입니다.
  
  if(convertView==null){
   view=inflater.inflate(R.layout.pokemon_list,parent,false)
  }


  val btnName=view?.findViewById<Button>(R.id.btnName)
  val tvPname:TextView?=view?.findViewById(R.id.tvPname)
  val tvAtk:TextView?=view?.findViewById(R.id.tvAtk)
  val tvFt:TextView?=view?.findViewById(R.id.tvFt)
  val imgPoke:ImageView?=view?.findViewById(R.id.imgPoke)

  imgPoke?.setImageResource(pokemonList[position].imgId)
  tvPname?.text=pokemonList[position].name
  tvAtk?.text=pokemonList[position].skill
  tvFt?.text=pokemonList[position].feature

  btnName?.setOnClickListener { Toast.makeText(context,tvPname?.text.toString(),Toast.LENGTH_SHORT).show() }
  //+btnName을 클릭했을때 포켓몬이름이 토스트창에 띄워지게 만들자


  // 이전에 만들어진 view가 null인상태에서 반드시 inflate가 발생한다!

  return view!! //setting이 된 view를 리턴하고있는상태
 }


}