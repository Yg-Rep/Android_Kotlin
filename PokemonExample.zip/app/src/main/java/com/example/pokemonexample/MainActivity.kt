package com.example.pokemonexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        //1. ListView의 위치 정해주기 --> main3.xml
        val lv: ListView =findViewById(R.id.lv)
        //2. ListView한 칸에 들어갈 디자인 만들기 --> pokemon_list.xml
        //3. 데이터 만들기 (이미지 아이디(Int), 이름,공격,특성)
        val pokemonList : MutableList<PokemonVO> = mutableListOf()
        pokemonList.add(PokemonVO(R.drawable.img1, "캐터피","날기","곤충"))
        pokemonList.add(PokemonVO(R.drawable.img2, "버터플","날기","곤충"))
        pokemonList.add(PokemonVO(R.drawable.img3, "피카츄","날기","곤충"))
        pokemonList.add(PokemonVO(R.drawable.img4, "푸린","날기","곤충"))
        pokemonList.add(PokemonVO(R.drawable.img5, "디그다","날기","곤충"))
        pokemonList.add(PokemonVO(R.drawable.img6, "냐옹","날기","곤충"))
        pokemonList.add(PokemonVO(R.drawable.img7, "발챙이","날기","곤충"))
        pokemonList.add(PokemonVO(R.drawable.img8, "캐이시","날기","곤충"))
        pokemonList.add(PokemonVO(R.drawable.img9, "우츠동","날기","곤충"))
        pokemonList.add(PokemonVO(R.drawable.img10, "꼬마돌","날기","곤충"))



        //img,name,atk,feature ----> PokeMonVO
        //4. Adapter 만들기 ---> PokeMonAdapter

        //val adapter=PokemonAdapter(applicationContext,R.layout.pokemon_list,pokemonList)
        //5. ListView에 내가만든 Adapter 적용시키기

        //6. Button을 클릭했을 때 Toast창에 포켓몬 이름 뜨게 만들기.





        val adapter =PokemonAdapter(applicationContext,R.layout.pokemon_list,pokemonList)
        lv.adapter=adapter



    }
}