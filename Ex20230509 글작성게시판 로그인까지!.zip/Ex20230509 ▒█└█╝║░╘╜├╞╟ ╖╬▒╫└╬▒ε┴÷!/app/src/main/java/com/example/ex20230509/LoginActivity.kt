package com.example.ex20230509

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etID:EditText=findViewById(R.id.etID)
        val etPW:EditText=findViewById(R.id.etPW)
        val btnResult:Button=findViewById(R.id.btnResult)

        btnResult.setOnClickListener {
            val id= etID.text.toString()
            val pw= etPW.text.toString()


            //이미 인텐트가 있으므로 정의를 할 필요가없는거죠
            if(id.equals("YG") && pw.equals("12345")){
                setResult(RESULT_OK,intent)
            }
            else{
                setResult(RESULT_CANCELED,intent)
            }
            finish()
            //피니쉬를 함으로서 꺼지기에 이전으로 돌아갑니다.
        }
    }
}