package com.example.ex20230509

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : AppCompatActivity() {

    lateinit var tvResult:TextView
    lateinit var btnLogin:Button
    lateinit var btnWrite:Button
    //이것은 후에 다시 초기화를 해줘야하기에 여기에 만들어줘야합니다.


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        tvResult=findViewById(R.id.tvResult)
        btnLogin=findViewById(R.id.btnLogin)
        btnWrite=findViewById(R.id.btnWrite)

        //로그인 전 btnWrite 비활성화
        btnWrite.isEnabled=false

        //btnLogin을 클릭하면 LoginActivity로 이동
        btnLogin.setOnClickListener {
            val intent=Intent(this,LoginActivity::class.java)

            //양방향 Intent사용 (intent,requestCode)

            forResult.launch(intent)
        }

    }
    //ActivityResultLauncher 함수 사용
    //: 액티비티에서 데이터(대용량)을 받아오기 위해서 사용
    //변수에다가 함수를 담아서 사용
    //registerForActivityResult(Constract 자료형, 콜백메서드 (생략가능))
    private val forResult= registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
        //it : resultCode,data
        if(it.resultCode== RESULT_OK){
            tvResult.text="이연규님 환영합니다"
            btnWrite.isEnabled=true
        }
        else{Toast.makeText(this,"로그인실패",Toast.LENGTH_SHORT).show()}
    }


}