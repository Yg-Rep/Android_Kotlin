package com.example.ex20230504

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class SubActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sub)


        //서브 Activity=> Main Activity로 넘어가는 명시적 Intent를 실행할겁니다
        //여기는 스택구조이기에 (FILO)

        val btnMain:Button=findViewById(R.id.btnMain)
        btnMain.setOnClickListener { finish() }
        // 저위에 finish()를 사용해서 쌓이던 Main이 아닌 sub가 빠져나가게해줄수있습니다.
    }
}