package com.example.ex20230504

import android.app.SearchManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val btnCall:Button=findViewById(R.id.btnCall)
        val btnWeb:Button=findViewById(R.id.btnWeb)
        val btnMap:Button=findViewById(R.id.btnMap)
        val btnSearch:Button=findViewById(R.id.btnSearch)
        val btnMsg:Button=findViewById(R.id.btnMsg)
        val btnCam:Button=findViewById(R.id.btnCam)
        val btnMove:Button=findViewById(R.id.btnMove)

        //Intent : 안드로이드 4대 구성 요소간 메세지 객체!
        //묵시적(암시적) Intent : 액션(Android)
        //명시적 Intent: 4대 구성요소간에 이동/데이터 전달!

        //아두이노 통신을 안드로이드와 할때 권한이 중요합니다.

        //전화거는기능
        btnCall.setOnClickListener {
            //내가 지정한 번호로 전화가 걸리게 만들어 주자

            // 묵시적 Intent를 사용 할때 2가지가 필요  어떤 액션, 데이터(URI)
            // tel:01056593231
            // :을 기준으로 왼쪽 어떤데이터인지 알려주는 키워드 : 오른쪽이 데이터
            val uri =Uri.parse("tel:010-5659-3231")
            // 다른 어플리케이션으로 넘어갈 수 있는 Intent 생성
            val intent2=Intent(Intent.ACTION_CALL,uri)


            //Intent가 실행되기 전에 권한이 허용되어있는지 확인
            //되어있으면 실행 아니면 권한허용받기
            //ActivityCompat:
            //checkSelfPermission():권한이 있는지 없는지
            // 2가지 매개변수
            // 1) 현재페이지 정보 this
            // 2) 어떤 권한 (종류)
            if(ActivityCompat.checkSelfPermission(applicationContext,android.Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED){
                // CallPhone 권한 != 허용
                // Alert창 띄우기

                // 요청 기능 또한 ActivityCompat에 설계되어있다.
                //1)현재 페이지의 정보
                //2) permission : Array
                //3) requestCode:명시적 인텐트(아무숫자넣어도됨)
                ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.CALL_PHONE),0)

                return@setOnClickListener
                //return 이라는 키워드가 없으면 권한을 설정하고 나서 어플리케이션 화면으로 돌아오지않는다.
            }


            //Intent 실행(시작)
            startActivity(intent2)
            //SecurityException: 보안예외상황
            //==> 사용자가 권한을 부여했는지 안했는지 확인
            //==> Alert창을 띄워서 권한 허용을 받아야한다.

        }

        btnWeb.setOnClickListener {
            val uri=Uri.parse("http://www.naver.com")
            val intent=Intent(Intent.ACTION_VIEW,uri)
            startActivity(intent)
        }

        btnMap.setOnClickListener {
            val uri=Uri.parse("https://google.com/maps?q=35.14670147841655,126.92215633785938")
            val intent=Intent(Intent.ACTION_VIEW,uri)
            startActivity(intent)
        }

        btnSearch.setOnClickListener {
            val intent=Intent(Intent.ACTION_WEB_SEARCH)
            //이번엔 putExtra를 통해서 인텐트에다가 실어서 보내버립시다.
            intent.putExtra(SearchManager.QUERY,"안드로이드")
            startActivity(intent)
        }
        btnMsg.setOnClickListener {
            val intent=Intent(Intent.ACTION_SENDTO)
            // 두가지: 메세지 내용 /누구한테보낼건지
            intent.putExtra("sms_body","안녕하세요") //메시지내용
            //1번째 방법. Uri.parse("tel:010-5659-3231")
            //2번째 방법.
            intent.data = Uri.parse("smsto:"+Uri.encode("010-5659-3231"))
            startActivity(intent)
        }

        //Emulator에는 카메라가 없음: 가상 환경
        //가상 환경: MediaStore.ACTION_IMAGE_CAPTURE
        //가상 환경을 캡쳐할 수 있는 액션
        //보내줄 데이터는 없습니다.
        btnCam.setOnClickListener {
            val intent= Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivity(intent)
        }

        //명시적 인텐트
        //:어플 내부에 만들어놓은 4대 구성 요소간의 이동/데이터 전송

        // 1. Activity ----> Activity 이동만
        btnMove.setOnClickListener {
            //시작 Activity , 도착하는 Activity(
            // kt클래스가아닌
            // java.class를 가지고 있어야 합니다 )
            val intent =Intent(this , SubActivity::class.java)
            startActivity(intent)
        }



    }
}