package com.example.ex20230502

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import java.util.Random


class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        // imgMon, tvHp, btnAtk라는 id값을 부여해주세요
        //id값을 통해 View를 찾아오기!
        val imgMon: ImageView =findViewById(R.id.ImgMon)
        val btnATK: Button=findViewById(R.id.btnAtk)
        val tvHP: TextView=findViewById(R.id.tvHP)


       val rd= Random()
       var hp= rd.nextInt(50)+1
//내가 못한것 1. 랜덤
        tvHP.text="HP $hp"
        //tvHP.setText("hp $hp")

        //내가 몰랐던 것 포맷팅 개어렵네



        btnATK.setOnClickListener {
            hp--
            tvHP.text="HP $hp"
            if (hp == 0) {
                imgMon.setImageResource(R.drawable.dead)
                btnATK.isEnabled=false
                tvHP.text="몬스터처치완료"
            }
        }

        //tvHP의 체력이 랜덤한 숫자를 가진채로 세팅되어야합니다
        //1-50사이에 체력을 가지게 만들어주고
        //체력이 0이되면 "몬스터 처치 완료 "
        //isEnabled 속성 사용해서 Button 비활성화 시키기 출발

    }
}