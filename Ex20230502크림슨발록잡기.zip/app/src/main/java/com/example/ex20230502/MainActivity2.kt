package com.example.ex20230502

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        //위의 setContentView가 시작된후에!
        //imgView,Button 아이디값을 찾아옵시다
   val imgKim:ImageView=findViewById(R.id.imgKim)
   val btnChange:Button=findViewById(R.id.btnChange)


        btnChange.setOnClickListener {
            imgKim.setImageResource(R.drawable.img2)
        }
    }
}