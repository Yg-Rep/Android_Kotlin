package com.example.ex20230502

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    //onCreate 메서드는 에뮬레이터를 실행시켰을때 딱! 한번만 실행
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        // 아이디 값을 찾아오고 싶으면 setContentView 아래 쪽에서 진행해 주시면 됩니다.
        setContentView(R.layout.activity_main)


        // tvLogin
        // val tvLogin
        //R.id.tvLogin R(res폴더에 아이디의 tvlogin)
        val tvLogin: TextView=findViewById<TextView>(R.id.tvLogin)
        //MainActivity클래스에서 tvLogin을 컨트롤 할 수 있는 상태
        val btnLogin:Button=findViewById(R.id.btnLogin)
        val etId:EditText=findViewById(R.id.etId)
        val etPw:EditText=findViewById(R.id.etPw)

        //1) tvLogin에 문구를 Log를 통해서 출력해보자
        //1. 검색키워드(Tag) 2. 확인해보고싶은 문구, 문자열
        //toString():Log,Toast를 띄울떄는 메시지가 반드시 문자열이어야함.
        //text : getText(),setText()
        Log.d("텍스트뷰",tvLogin.text.toString())

        //2) tvLogin에 있는 문구를 Toast창으로 띄워보자 -> (에뮬레이터 확인)

        // 1. 어디화면에 띄울건지 화면정보
        // 2. 문구(String), 아이디(Int)
        // 3. Duration 지속시간

        Toast.makeText(this@MainActivity,
        tvLogin.text.toString(),
        Toast.LENGTH_SHORT).show()
        //에뮬레이터에서 확인할 수 있는 방법.

       //btnLogin을 클릭 했을 때 Toast창이 띄워지게 만들자
        //1)속성 onclick 함수를 적용 ---> 메모리 공간에 만들어 놓은 함수 -> 고로 너무 공간을 차지해서 잘안씁니다.
        //2) setOnClickListener{View.Onclick(){Onclick}} => 람다특징 setOnClickListener{}


//        btnLogin.setOnClickListener {
//            //버튼을 클릭 했을때 어떤 코드가 실행되게 만들건지 {작성}
//            Toast.makeText(this@MainActivity,"클릭했습니다.",Toast.LENGTH_SHORT).show()
//        }

        btnLogin.setOnClickListener {
            if(etId.text.toString()=="smhrd" &&etPw.text.toString()=="12345"){
                Toast.makeText(this@MainActivity,"로그인성공",Toast.LENGTH_LONG).show()
            }
            else{Toast.makeText(this@MainActivity,"로그인실패",Toast.LENGTH_LONG).show()}
        }
        //사용자가 ID:smhrd Pw:12345를 입력하고 눌렀을때 로그인 성공이라는 문구가 토스트창에 뜨게해주세요 ^^
    }
//    fun click(view:View):Unit{Toast.makeText(this@MainActivity,"클릭이 감지되었습니다.",Toast.LENGTH_SHORT).show()}







}